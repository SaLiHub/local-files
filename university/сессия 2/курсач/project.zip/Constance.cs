﻿namespace Game_Caro
{
    class Constance
    {
        public static int CellWidth = 35;
        public static int CellHeight = 35;

        public static int nRows = 22;
        public static int nCols = 40;

        public static int CountDownStep = 100;
        public static int CountDownTime = 10000;
        public static int CountDownInterval = 100;
    }
}
